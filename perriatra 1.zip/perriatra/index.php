<?php
 session_start();
 if (!isset($_SESSION['nombre'])) {
    header('Location: ./vista/login.php');
    exit();
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mascotas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body class="index-bg">
    <!-- Header con mensaje de bienvenida y botones -->
    <header class="container-fluid">
        <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center py-3 gap-3">
            <div>
                <?php
                if (isset($_SESSION['nombre'])) {
                    echo "<h1 class='mb-0 text-green'>¡Bienvenido, " . htmlspecialchars($_SESSION['nombre']) . "!</h1>";
                } else {
                    echo "<h1 class='mb-0 text-green'>Bienvenido a Perriatra</h1>";
                }
                ?>
            </div>
            <div class="mt-3 mt-md-0 d-flex flex-column flex-sm-row gap-2">
                <a href="./vista/propietarios.php" class="btn btn-info btn-lg">Propietarios</a>
                <a href="./vista/agregar_mascota.php" class="btn btn-green btn-lg">Añadir Mascota</a>
                <a href="./procesos/cerrar_sesion.php" class="btn btn-danger btn-lg">Cerrar Sesión</a>
            </div>
        </div>
    </header>
    <div class="container mt-4 mt-md-5">
        <!-- Filtros -->
        <section class="filtros mb-4 col-md-8 col-lg-6 mx-auto p-3">
            <h2>Filtrar Mascotas</h2>
            <form action="index.php" method="get" class="row g-3 align-items-end">
                <div class="col-12 col-md-auto">
                    <label for="especie" class="form-label">Especie:</label>
                    <select name="especie" id="especie" class="form-select">
                        <option value="">Todas</option>
                        <?php
                        include './procesos/connect.php';
                        $listaEspecies = [];
                        $resEspecies = mysqli_query($conn, "SELECT DISTINCT Especie FROM mascota");
                        while ($esp = mysqli_fetch_assoc($resEspecies)) {
                            $listaEspecies[] = $esp['Especie'];
                        }
                        foreach ($listaEspecies as $especie) {
                            $selected = (isset($_GET['especie']) && $_GET['especie'] == $especie) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($especie) . "' $selected>" . htmlspecialchars($especie) . "</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-12 col-md-auto">
                    <label for="genero" class="form-label">Género:</label>
                    <select name="genero" id="genero" class="form-select">
                        <option value="">Todos</option>
                        <?php
                        $listaGeneros = [];
                        $resGeneros = mysqli_query($conn, "SELECT DISTINCT Genere FROM mascota");
                        while ($gen = mysqli_fetch_assoc($resGeneros)) {
                            $listaGeneros[] = $gen['Genere'];
                        }
                        foreach ($listaGeneros as $genero) {
                            $selected = (isset($_GET['genero']) && $_GET['genero'] == $genero) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($genero) . "' $selected>" . htmlspecialchars($genero) . "</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-12 col-md-auto">
                    <button type="submit" class="btn btn-primary">Filtrar</button>
                    <a href="index.php" class="btn btn-secondary">Quitar filtros</a>
                </div>
            </form>
        </section>
        <!-- Barra superior con título -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 gap-3">
            <h2 class="index-title-white mb-0">Lista de Mascotas</h2>
        </div>
        <!-- Tabla de mascotas -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Nombre</th>
                        <th>Especie</th>
                        <th>Raza</th>
                        <th>Género</th>
                        <th>Fecha de Nacimiento</th>
                        <th>Propietario</th>
                        <th>Veterinario</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Construir consulta con filtros
                    $where = [];
                    if (isset($_GET['especie']) && $_GET['especie'] !== '') {
                        $especie = mysqli_real_escape_string($conn, $_GET['especie']);
                        $where[] = "Especie = '$especie'";
                    }
                    if (isset($_GET['genero']) && $_GET['genero'] !== '') {
                        $genero = mysqli_real_escape_string($conn, $_GET['genero']);
                        $where[] = "Genere = '$genero'";
                    }
                    $sql = "SELECT * FROM mascota";
                    if (count($where) > 0) {
                        $sql .= " WHERE " . implode(' AND ', $where);
                    }
                    $result = mysqli_query($conn, $sql);

                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['Nombre']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Especie']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Raza']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Genere']) . "</td>";
                            echo "<td>"  . htmlspecialchars($row['Fecha_Nacimiento']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Propietario']) . "</td>";
                            echo "<td>" . ($row['Vet']) . "</td>"; 
                            echo "<td>";
                           
                            if (isset($row['chip'])) {
                                // Acciones: Editar y Eliminar juntos
                                echo "<a href='./procesos/modificar/modificar_animal.php?chip=" . htmlspecialchars($row['chip']) . "' class='btn btn-warning btn-sm me-2'>Editar</a>";
                                echo "<a href='./procesos/eliminar/eliminar_animal.php?chip=" . htmlspecialchars($row['chip']) . "' class='btn btn-danger btn-sm'>Eliminar</a>";
                            } else {
                                echo "<span class='text-danger'>ID no disponible</span>";
                            }
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>No hay mascotas registradas</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>
</html>