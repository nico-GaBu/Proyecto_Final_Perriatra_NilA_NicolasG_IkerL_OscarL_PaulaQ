// Utilidad para mostrar/limpiar errores
function mostrarError(inputId, mensaje) {
    var input = document.getElementById(inputId);
    var errorId = inputId + "-error";
    var errorElem = document.getElementById(errorId);
    if (!errorElem) {
        errorElem = document.createElement("div");
        errorElem.id = errorId;
        errorElem.style.color = "red";
        errorElem.style.fontSize = "0.9em";
        input.parentNode.appendChild(errorElem);
    }
    errorElem.textContent = mensaje;
    input.classList.add("is-invalid");
}
function limpiarError(inputId) {
    var input = document.getElementById(inputId);
    var errorId = inputId + "-error";
    var errorElem = document.getElementById(errorId);
    if (errorElem) {
        errorElem.textContent = "";
    }
    input.classList.remove("is-invalid");
}

// Usuario (login/registro)
function validarNombreLogin() {
    var input = document.getElementById("nombre") || document.getElementById("username");
    if (!input) return true;
    var nombre = input.value.trim();
    var regex = /^[a-zA-Z0-9]+$/;
    if (!nombre) {
        mostrarError(input.id, "El nombre de usuario es obligatorio.");
        return false;
    }
    if (nombre.length < 3 || nombre.length > 20 || !regex.test(nombre)) {
        mostrarError(input.id, "El nombre debe tener entre 3 y 20 caracteres y solo puede contener letras y números.");
        return false;
    }
    limpiarError(input.id);
    return true;
}

// Email (registro)
function validarEmailRegistro() {
    var input = document.getElementById("email");
    if (!input) return true;
    var email = input.value.trim();
    var regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!email) {
        mostrarError("email", "El email es obligatorio.");
        return false;
    }
    if (!regex.test(email)) {
        mostrarError("email", "El email no es válido.");
        return false;
    }
    limpiarError("email");
    return true;
}

// Contraseña (login/registro)
function validarContrasenaLogin() {
    var input = document.getElementById("pass") || document.getElementById("password");
    if (!input) return true;
    var contrasena = input.value;
    var inputId = input ? input.getAttribute("id") : "";
    if (!contrasena) {
        mostrarError(inputId, "La contraseña es obligatoria.");
        return false;
    }
    if (contrasena.length < 8) {
        mostrarError(inputId, "La contraseña debe tener al menos 8 caracteres.");
        return false;
    }
    if (!/[A-Z]/.test(contrasena)) {
        mostrarError(inputId, "La contraseña debe contener al menos una letra mayúscula.");
        return false;
    }
    if (!/\d/.test(contrasena)) {
        mostrarError(inputId, "La contraseña debe contener al menos un número.");
        return false;
    }
    limpiarError(inputId);
    return true;
}

// Confirmar contraseña (registro)
function validarConfirmarContrasenaRegistro() {
    var input = document.getElementById("passConf") || document.getElementById("confirm_password");
    var passInput = document.getElementById("pass") || document.getElementById("password");
    if (!input || !passInput) return true;
    var contrasena = passInput.value;
    var confirmarContrasena = input.value;
    if (!confirmarContrasena) {
        mostrarError(input.id, "Debes confirmar la contraseña.");
        return false;
    }
    if (contrasena !== confirmarContrasena) {
        mostrarError(input.id, "Las contraseñas no coinciden.");
        return false;
    }
    limpiarError(input.id);
    return true;
}

// Especialidad (registro)
function validarEspecialidad() {
    var input = document.getElementById("especialidad");
    if (!input) return true;
    var val = input.value.trim();
    if (!val) {
        mostrarError("especialidad", "La especialidad es obligatoria.");
        return false;
    }
    if (!/^[a-zA-Z\s]+$/.test(val)) {
        mostrarError("especialidad", "La especialidad solo debe contener letras y espacios.");
        return false;
    }
    limpiarError("especialidad");
    return true;
}

// Teléfono (registro)
function validarTelefono() {
    var input = document.getElementById("telefono");
    if (!input) return true;
    var val = input.value.trim();
    if (!val) {
        mostrarError("telefono", "El teléfono es obligatorio.");
        return false;
    }
    if (!/^[0-9]{9,15}$/.test(val)) {
        mostrarError("telefono", "El teléfono debe contener entre 9 y 15 dígitos.");
        return false;
    }
    limpiarError("telefono");
    return true;
}

// Salario (registro)
function validarSalario() {
    var input = document.getElementById("salario");
    if (!input) return true;
    var val = input.value.trim();
    if (!val) {
        mostrarError("salario", "El salario es obligatorio.");
        return false;
    }
    if (isNaN(val) || Number(val) < 0) {
        mostrarError("salario", "El salario debe ser un número positivo.");
        return false;
    }
    limpiarError("salario");
    return true;
}

// Fecha (registro)
function validarFechaRegistro() {
    var input = document.getElementById("fecha");
    if (!input) return true;
    var val = input.value.trim();
    if (!val) {
        mostrarError("fecha", "La fecha de contratación es obligatoria.");
        return false;
    }
    limpiarError("fecha");
    return true;
}

// Mascota: Nombre
function validarNombreMascota() {
    var input = document.getElementById("nombre");
    if (!input) return true;
    var nombre = input.value.trim();
    if (!nombre) {
        mostrarError("nombre", "El nombre de la mascota es obligatorio.");
        return false;
    }
    if (nombre.length < 2 || nombre.length > 25) {
        mostrarError("nombre", "El nombre de la mascota debe tener entre 2 y 25 caracteres.");
        return false;
    }
    limpiarError("nombre");
    return true;
}

// Mascota: Especie
function validarEspecieMascota() {
    var input = document.getElementById("especie");
    if (!input) return true;
    var especie = input.value.trim();
    if (!especie) {
        mostrarError("especie", "La especie es obligatoria.");
        return false;
    }
    if (especie.length < 2 || especie.length > 20) {
        mostrarError("especie", "La especie debe tener entre 2 y 20 caracteres.");
        return false;
    }
    limpiarError("especie");
    return true;
}

// Mascota: Raza
function validarRazaMascota() {
    var input = document.getElementById("raza");
    if (!input) return true;
    var raza = input.value.trim();
    if (!raza) {
        mostrarError("raza", "La raza es obligatoria.");
        return false;
    }
    limpiarError("raza");
    return true;
}

// Mascota: Género
function validarGeneroMascota() {
    var input = document.getElementById("genere") || document.getElementById("genero");
    if (!input) return true;
    var genero = input.value.trim();
    if (!genero) {
        mostrarError(input.id, "El género es obligatorio.");
        return false;
    }
    if (genero !== "M" && genero !== "H" && genero !== "O" && genero !== "Macho" && genero !== "Hembra" && genero !== "Otro") {
        mostrarError(input.id, "El género debe ser M, H, O, Macho, Hembra u Otro.");
        return false;
    }
    limpiarError(input.id);
    return true;
}

// Mascota: Fecha de nacimiento
function validarFechaMascota() {
    var input = document.getElementById("fecha_nacimiento") || document.getElementById("fecha");
    if (!input) return true;
    var fecha = input.value.trim();
    if (!fecha) {
        mostrarError(input.id, "La fecha de nacimiento es obligatoria.");
        return false;
    }
    limpiarError(input.id);
    return true;
}


// Validación general del formulario de login
function validarFormularioLogin() {
    var valido = true;
    if (!validarNombreLogin()) valido = false;
    if (!validarContrasenaLogin()) valido = false;
    return valido;
}

// Validación general del formulario de registro de veterinario
function validarFormularioRegistroVeterinario() {
    var valido = true;
    if (!validarEmailRegistro()) valido = false;
    if (!validarNombreLogin()) valido = false;
    if (!validarContrasenaLogin()) valido = false;
    if (!validarConfirmarContrasenaRegistro()) valido = false;
    if (!validarEspecialidad()) valido = false;
    if (!validarTelefono()) valido = false;
    if (!validarSalario()) valido = false;
    if (!validarFechaRegistro()) valido = false;
    return valido;
}

// Validación general del formulario de mascota
function validarFormularioMascota() {
    var valido = true;
    if (!validarNombreMascota()) valido = false;
    if (!validarEspecieMascota()) valido = false;
    if (!validarRazaMascota()) valido = false;
    if (!validarGeneroMascota()) valido = false;
    if (!validarFechaMascota()) valido = false;
    return valido;
}
