<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Veterinario</title>
</head>
<body>
<?php
include "../connect.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql_eliminar_veterinario = "DELETE FROM veterinario WHERE id = ?";
    $stmt_veterinario = mysqli_prepare($conn, $sql_eliminar_veterinario);
    // aqui se vincula parámetros a una sentecia preparada
    mysqli_stmt_bind_param($stmt_veterinario, "i", $id);
    $resultado_veterinario = mysqli_stmt_execute($stmt_mascota);
    mysqli_stmt_close($stmt_veterinario);
    
    //Ejecutamos las consultas
    if ($resultado_veterinario) {
        echo "<p>Veterinario eliminado correctamente.</p>";
    } else {
        echo "<p>Error al eliminar al veterinario: " . mysqli_error($conn) . "</p>";
    }
    } else {
        echo "<p>ID no proporcionado para eliminar.</p>";
    }

mysqli_close($conn);
?>
<p><a href="../index.php">Volver</a></p>


</body>
</html>