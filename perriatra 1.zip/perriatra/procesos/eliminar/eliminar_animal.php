<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Animal</title>
</head>
<body>
<?php
 include "../connect.php";


if (isset($_GET['chip'])) {
    $chip = $_GET['chip'];

    // Eliminamos Mascotas
    $sql_eliminar_mascota = "DELETE FROM mascota WHERE chip = ?";
    $stmt_mascota = mysqli_prepare($conn, $sql_eliminar_mascota);
    // aqui se vincula parámetros a una sentecia preparada
    mysqli_stmt_bind_param($stmt_mascota, "i", $chip);
    $resultado_mascota = mysqli_stmt_execute($stmt_mascota);
    mysqli_stmt_close($stmt_mascota);


    if ($resultado_mascota) {
        echo "<p>Registros eliminados correctamente.</p>";
        header('Location: ../../index.php');
    } else {
        echo "<p>Error al eliminar: " . mysqli_error($conn) . "</p>";
    }

} else {
    echo "<p>ID no proporcionado para eliminar.</p>";
}

mysqli_close($conn);
?>

</body>
</html>