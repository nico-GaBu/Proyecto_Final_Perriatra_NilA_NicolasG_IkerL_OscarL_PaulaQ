
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Propietario</title>
</head>
<body>
<?php
 include "../connect.php";


if (isset($_GET['DNI'])) {
    $DNI = $_GET['DNI'];
// Eliminamos propietario
    $sql_eliminar_propietario = "DELETE FROM propietario WHERE DNI = ?";
    $stmt_propietario = mysqli_prepare($conn, $sql_eliminar_propietario);
    // aqui se vincula parámetros a una sentecia preparada
    mysqli_stmt_bind_param($stmt_propietario, "s", $DNI);
    $resultado_propietario = mysqli_stmt_execute($stmt_propietario);
    mysqli_stmt_close($stmt_propietario);

    if ( $resultado_propietario) {
        echo "<p>Registros eliminados correctamente.</p>";
        header('Location: ../../vista/propietarios.php');
    } else {
        echo "<p>Error al eliminar: " . mysqli_error($conn) . "</p>";
    }

} else {
    echo "<p>DNI no proporcionado para eliminar.</p>";
}
mysqli_close($conn);
?>
<p><a href="../../index.php">Volver a la lista</a></p>


</body>
</html>