<?php
include "../connect.php";
session_start();


// Verificar si el formulario fue enviado correctamente
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['chip'], $_POST['nombre'], $_POST['genere'], $_POST['raza'], $_POST['especie'], $_POST['fecha_nacimiento'], $_POST['propietario'], $_POST['vet'])) {
    $chip = $_POST['chip'];
    $nombre = $_POST['nombre'];
    $genero = $_POST['genere'];
    $raza = $_POST['raza'];
    $especie = $_POST['especie'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $propietario = $_POST['propietario'];
    $vet = $_POST['vet'];

    // Actualizar los datos de la mascota
    $sql = "UPDATE mascota SET nombre = ?, especie = ?,  raza = ?, genere = ?, fecha_nacimiento = ?, propietario = ?, vet = ? WHERE chip = ?";
    $stmt_update = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt_update, "ssssssss", $nombre, $especie, $raza, $genero, $fecha_nacimiento, $propietario, $vet, $chip);
        $resultado_update = mysqli_stmt_execute($stmt_update);
        mysqli_stmt_close($stmt_update);

        if ($resultado_update) {
            header("Location: ../../index.php");
            exit();
        } else {
            echo "<p>Error al actualizar la mascota: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p>ID no encontrado.</p>";
    }


mysqli_close($conn);
?>
