<?php
include "../connect.php";
session_start();


// Verificar si el formulario fue enviado correctamente
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['dni'], $_POST['nombre'], $_POST['telf'], $_POST['email'], $_POST['direccion'])) {
    $dni = $_REQUEST['dni'];
    $nombre = $_REQUEST['nombre'];
    $telf = $_REQUEST['telf'];
    $email = $_REQUEST['email'];
    $direccion = $_REQUEST['direccion'];
    $error = false;

    // Actualizar los datos de la mascota
    $sql = "UPDATE propietario SET nombre = ?, telf = ?, direccion = ?, mail = ? WHERE dni = ?";
    $stmt_update = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt_update, "sisss", $nombre, $telf, $direccion, $email, $dni);
        $resultado_update = mysqli_stmt_execute($stmt_update);
        mysqli_stmt_close($stmt_update);

        if ($resultado_update) {
            header("Location: ../../vista/propietarios.php");
            exit();
        } else {
            echo "<p>Error al actualizar el propietario: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p>DNI no encontrado.</p>";
    }


mysqli_close($conn);
?>
