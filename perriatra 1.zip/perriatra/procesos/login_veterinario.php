<?php
session_start();

// Conexión BBDD
include '../procesos/connect.php';

// Verificar conexión
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Validar que la petición sea POST y contenga los campos esperados
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../vista/login.php");
    exit();
}

if (!isset($_POST['nombre'])  && !isset($_POST['pass'])) {
    echo "Nombre y contraseña son obligatorios.";
    exit();
}

// Recoger datos del formulario
$nombre = ($_POST['nombre']);
$password = ($_POST['pass']);

// Validación básica
if (empty($nombre)  && empty($password)) {
    echo "DNI y contraseña son obligatorios.";
    exit;
}

// Buscar veterinario por nombre
$query = "SELECT * FROM veterinario WHERE Nombre = '$nombre'";
$resultado = mysqli_query($conn, $query);


if ($fila = mysqli_fetch_assoc($resultado)) {

    // Verificar contraseña (encriptada)
    if (password_verify($password, $fila['password'])) {
        // Iniciar sesión
        $_SESSION['nombre'] = $fila['Nombre'];
        $_SESSION['pass'] = $fila['password'];

        // Redirigir
        header("Location: ../index.php");
        exit;
    } else {
        echo "Contraseña incorrecta.";
    }
} else {
    echo "No existe un veterinario con ese nombre.";
}

// Cerrar conexión
mysqli_close($conn);