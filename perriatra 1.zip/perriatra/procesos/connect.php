<?php
    $servername = "localhost";  
    $username = "root";           
    $password = "";
    $bd = "bd_perriatra";

$conn = mysqli_connect($servername, $username, $password, $bd);

// Verificar la conexión
if (!$conn) {
    echo "<script>alert('Conexion Fallida')</script>";
    die("Error de conexión: " . mysqli_connect_error());
}
?>
