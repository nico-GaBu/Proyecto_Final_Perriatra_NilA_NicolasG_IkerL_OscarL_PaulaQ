<?php
session_start();
// Conexión a la base de datos de perriatra
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recogida de datos
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['pass'];
    $passHash = password_hash($password, PASSWORD_DEFAULT);
    $especialidad = $_POST['especialidad'];
    $telefono = $_POST['telefono'];
    $salario = $_POST['salario'];
    $fecha = $_POST['fecha'];
    

    // Preparar la consulta
    $sql = "INSERT INTO veterinario (email, Nombre, password, Especialidad, Fecha_Contrato, Salario, Telf) VALUES (?, ?, ?, ?, now(), ?, ?)";
    $result = mysqli_prepare($conn, $sql);

    if ($result) {
        // Vincular los parámetros (email, Nombre, password)
        mysqli_stmt_bind_param($result, "ssssdi", $email, $username, $passHash, $especialidad, $salario, $telefono);

        // Ejecutar la sentencia
        if (mysqli_stmt_execute($result)) {
            header("Location: ../index.php");
            exit();
        } else {
            echo "Error al insertar el usuario: " . mysqli_stmt_error($result);
        }

        mysqli_stmt_close($result);

    } else {
        echo "Error al preparar la consulta: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
