<?php
include "../connect.php";
session_start();
if (!isset($_SESSION['nombre'])) {
    header('Location: ../../vista/login.php');
    exit();
}

// verificar se se ha recibido un ID válido
if (!isset($_GET['id'])) {
    echo "ID de veterinario no válido.";
    exit();
}

$id = $_GET['id'];

// Obtener los datos de veterinario
$sql = "SELECT * FROM veterinario WHERE id = $id";
$result = mysqli_query($conn, $sql);
$veterinario = mysqli_fetch_assoc($result);

if (!$veterinario) {
    echo " Veterinario no encontrado.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Veterinario</title>
</head>
<body>
<div class="header">
    <div class="logo-title">
        <img src="../img/perro.png" alt="Perro">
        <h2>Modificar Veterinario</h2>
    </div>
    <a href="../vista/agregar_mascota.php"><button class="btn-back">Atrás</button></a>
</div>

    <form action="./update.php" method="post">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        
        <label>Nombre:</label>
        <input type="text" name="nombre" value="<?php echo $nombre['nombre']; ?>" required>
        <br>

        <label>Telefono:</label>
        <input type="text" name="telefono" value="<?php echo $telefono['telefono']; ?>" required>
        <br>

        <label>Especialidad:</label>
        <input type="text" name="especialidad" value="<?php echo $especialidad['especialidad']; ?>" required>
        <br>

        <label>Fecha Contrato:</label>
        <input type="text" name="fecha_contrato" value="<?php echo $fecha_contraro['fecha_contraro']; ?>" required>
        <br>

        <label>Salario:</label>
        <input type="text" name="salario" value="<?php echo $salario['salario']; ?>" required>
        <br>
        
        <button type="submit">Guardar cambios</button>
    </form>  
</body>
</html>
