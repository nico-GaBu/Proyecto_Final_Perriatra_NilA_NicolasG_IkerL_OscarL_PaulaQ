<?php
include '../connect.php';
session_start();
if (!isset($_SESSION['nombre'])) {
    header('Location: ../../vista/login.php');
    exit();
}

if (!isset($_GET['chip'])) {
    echo "Chip de Mascota no válido.";
    exit();
}

$chip = $_GET['chip'];
$sql = "SELECT * FROM mascota WHERE chip = $chip";
$result = mysqli_query($conn, $sql);
$mascota = mysqli_fetch_assoc($result);

if (!$mascota) {
    echo "Mascota no encontrada.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Mascota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/styles.css"> <!-- Reutiliza tu CSS personalizado -->
</head>
<body class="bg-green d-flex align-items-center min-vh-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-8 col-lg-6 px-1 px-sm-2">
                <div class="card shadow-lg p-3 p-sm-4">
                    <h2 class="mb-4 text-white text-center bg-green py-2 rounded">Modificar Mascota</h2>
                    <form action="../update/update_mascota.php" method="post">
                        <input type="hidden" name="chip" value="<?php echo $chip; ?>">

                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo $mascota['Nombre']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="genere" class="form-label">Género:</label>
                            <input type="text" class="form-control" id="genere" name="genere" value="<?php echo $mascota['Genere']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="especie" class="form-label">Especie:</label>
                            <input type="text" class="form-control" id="especie" name="especie" value="<?php echo $mascota['Especie']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="raza" class="form-label">Raza:</label>
                            <select id="raza" name="raza" class="form-control" required>
                                <option value="">Seleccione una raza</option>
                                <?php
                                $sql = "SELECT * FROM raza";
                                $result = mysqli_query($conn, $sql);
                                if ($result) {
                                    $razas = mysqli_fetch_all($result, MYSQLI_ASSOC);
                                    foreach ($razas as $row) {
                                        $selected = $mascota['Raza'] == $row['Id'] ? 'selected' : '';
                                        echo "<option value='" . htmlspecialchars($row['Id']) . "' $selected>" . htmlspecialchars($row['Nombre']) . "</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="fecha_nacimiento" class="form-label">Fecha de Nacimiento:</label>
                            <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo $mascota['Fecha_Nacimiento']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="propietario" class="form-label">Propietario:</label>
                            <select id="propietario" name="propietario" class="form-control" required>
                                <option value="">Seleccione un propietario</option>
                                <?php
                                $sql = "SELECT * FROM propietario";
                                $result = mysqli_query($conn, $sql);
                                if ($result) {
                                    $propietarios = mysqli_fetch_all($result, MYSQLI_ASSOC);
                                    foreach ($propietarios as $row) {
                                        $selected = $mascota['Propietario'] == $row['DNI'] ? 'selected' : '';
                                        echo "<option value='" . htmlspecialchars($row['DNI']) . "' $selected>" . htmlspecialchars($row['Nombre']) . "</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="vet" class="form-label">Veterinario:</label>
                            <select id="vet" name="vet" class="form-control" required>
                                <option value="">Seleccione un veterinario</option>
                                <?php
                                $sql = "SELECT * FROM veterinario";
                                $result = mysqli_query($conn, $sql);
                                if ($result) {
                                    $veterinarios = mysqli_fetch_all($result, MYSQLI_ASSOC);
                                    foreach ($veterinarios as $row) {
                                        $selected = $mascota['Vet'] == $row['Id'] ? 'selected' : '';
                                        echo "<option value='" . htmlspecialchars($row['Id']) . "' $selected>" . htmlspecialchars($row['Nombre']) . "</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>

                        <div class="d-flex flex-column flex-sm-row justify-content-between gap-2 mt-4">
                            <button type="submit" class="btn btn-success px-4">Guardar cambios</button>
                            <a href="../../index.php" class="btn btn-secondary px-4">Volver</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
