<?php
include "../connect.php";
session_start();
if (!isset($_SESSION['nombre'])) {
    header('Location: ../../vista/login.php');
    exit();
}

// Verificar si se ha recibido un DNI válido
if (!isset($_GET['DNI'])) {
    echo "DNI de Propietario no válido.";
    exit();
}

$DNI = $_GET['DNI'];

// Obtener datos del propietario
$sql = "SELECT * FROM propietario WHERE DNI = '$DNI'";
$result = mysqli_query($conn, $sql);
$propietario = mysqli_fetch_assoc($result);

if (!$propietario) {
    echo "Propietario no encontrado.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Propietario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/styles.css">
</head>
<body class="bg-green d-flex align-items-center min-vh-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-8 col-lg-6 px-1 px-sm-2">
                <div class="card shadow-lg p-2 p-sm-4">
                    <h2 class="mb-4 text-white text-center bg-green py-2 rounded">Modificar Propietario</h2>

                    <form action="../update/update_propietario.php" method="post">
                        <input type="hidden" name="dni" value="<?php echo $DNI; ?>">

                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo htmlspecialchars($propietario['Nombre']); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="telf" class="form-label">Teléfono</label>
                            <input type="number" class="form-control" id="telf" name="telf" value="<?php echo htmlspecialchars($propietario['Telf']); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="direccion" class="form-label">Dirección</label>
                            <input type="text" class="form-control" id="direccion" name="direccion" value="<?php echo htmlspecialchars($propietario['Direccion']); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($propietario['Mail']); ?>" required>
                        </div>

                        <div class="d-flex flex-column flex-sm-row justify-content-between gap-2">
                            <button type="submit" class="btn btn-success px-4">Guardar cambios</button>
                            <a href="../../vista/propietarios.php" class="btn btn-secondary px-4">Volver</a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
