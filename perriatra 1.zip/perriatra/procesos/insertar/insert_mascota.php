<?php
include "../connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nombre = $_REQUEST['nombre'];
    $genere = $_REQUEST['genere'];
    $especie = $_REQUEST['especie'];
    $raza = $_REQUEST['raza'];
    $fecha_nacimiento = $_REQUEST['fecha_nacimiento'];
    $propietario = $_REQUEST['propietario'];
    $veterinario = $_REQUEST['vet'];
    $error = false;

    // Insertar mascota
    $query1 = "INSERT INTO mascota(Nombre, Especie, Raza, Genere, Fecha_Nacimiento, Propietario , Vet) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $sentencia1 = mysqli_prepare($conn, $query1);

    if ($sentencia1) {
        // Asumiendo que propietario y veterinario son IDs numéricos (int), el resto son strings
        mysqli_stmt_bind_param($sentencia1, "ssissii", $nombre, $especie, $raza, $genere, $fecha_nacimiento, $propietario, $veterinario);

        if (!mysqli_stmt_execute($sentencia1)) {
            $error = true;
        }
        mysqli_stmt_close($sentencia1);
    } else {
        $error = true;
    }

    // Manejo de errores y redirección
    if ($error) {
        header("Location:../../index.php?error=1");
    } else {
        header("Location:../../index.php");
    }
} else {
    header("Location:../../index.php?error=1");
}
// Cerrar conexión
mysqli_close($conn);
?>

