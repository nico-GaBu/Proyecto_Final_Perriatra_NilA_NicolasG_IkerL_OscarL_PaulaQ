<?php

// Procesamiento del formulario
include '../connect.php';
session_start();
if (!isset($_SESSION['nombre'])) {
    header('Location: ../../vista/login.php');
    exit();
}

$dni = $nombre = $direccion = $telefono = $mail = "";
$dniError = $nombreError = $direccionError = $telefonoError = $mailError = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $valid = true;

    // Validaciones básicas
    if (empty($_POST['dni'])) {
        $dniError = "El DNI es obligatorio.";
        $valid = false;
    } else {
        $dni = trim($_POST['dni']);
    }

    if (empty($_POST['nombre'])) {
        $nombreError = "El nombre es obligatorio.";
        $valid = false;
    } else {
        $nombre = trim($_POST['nombre']);
    }

    if (empty($_POST['telf'])) {
        $telefonoError = "El teléfono es obligatorio.";
        $valid = false;
    } else {
        $telefono = trim($_POST['telf']);
    }

    if (empty($_POST['mail'])) {
        $mailError = "El email es obligatorio.";
        $valid = false;
    } else {
        $mail = trim($_POST['mail']);
        if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
            $mailError = "El email no es válido.";
            $valid = false;
        }
    }
    if (empty($_POST['direccion'])) {
        $dniError = "La direccion es obligatoria.";
        $valid = false;
    } else {
        $dni = trim($_POST['direccion']);
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $dni = $_REQUEST['dni'];
    $nombre = $_REQUEST['nombre'];
    $telf = $_REQUEST['telf'];
    $email = $_REQUEST['email'];
    $direccion = $_REQUEST['direccion'];
    $error = false;

    // Insertar mascota
    $query1 = "INSERT INTO propietario(dni, nombre, direccion, telf, mail) VALUES (?, ?, ?, ?, ?)";
    $sentencia1 = mysqli_prepare($conn, $query1);

    if ($sentencia1) {
        // Asumiendo que propietario y veterinario son IDs numéricos (int), el resto son strings
        mysqli_stmt_bind_param($sentencia1, "sssss",$dni, $nombre, $direccion, $telefono, $email);

        if (!mysqli_stmt_execute($sentencia1)) {
            $error = true;
        }
        mysqli_stmt_close($sentencia1);
    } else {
        $error = true;
    }

    // Manejo de errores y redirección
    if ($error) {
        header("Location:../../vista/propietarios.php?error=1");
    } else {
        header("Location:../../vista/propietarios.php");
    }
} else {
    header("Location:../../vista/propietarios.php?error=1");
}
}
// Cerrar conexión
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Añadir Propietario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/styles.css">
</head>
<body class="bg-green d-flex align-items-center min-vh-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-8 col-lg-6 px-1 px-sm-2">
                <div class="card shadow-lg p-2 p-sm-4">
                    <h2 class="mb-4 text-white text-center bg-green py-2 rounded">Añadir Nuevo Propietario</h2>
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="dni" class="form-label">DNI</label>
                            <input type="text" class="form-control <?php echo $dniError ? 'is-invalid' : ''; ?>" id="dni" name="dni" value="<?php echo htmlspecialchars($dni); ?>">
                            <div class="invalid-feedback"><?php echo $dniError; ?></div>
                        </div>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" class="form-control <?php echo $nombreError ? 'is-invalid' : ''; ?>" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>">
                            <div class="invalid-feedback"><?php echo $nombreError; ?></div>
                        </div>
                        <div class="mb-3">
                            <label for="telf" class="form-label">Teléfono</label>
                            <input type="text" class="form-control <?php echo $telefonoError ? 'is-invalid' : ''; ?>" id="telf" name="telf" value="<?php echo htmlspecialchars($telefono); ?>">
                            <div class="invalid-feedback"><?php echo $telefonoError; ?></div>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control <?php echo $mailError ? 'is-invalid' : ''; ?>" id="email" name="email" value="<?php echo htmlspecialchars($mail); ?>">
                            <div class="invalid-feedback"><?php echo $mailError; ?></div>
                        </div>
                        <div class="mb-3">
                            <label for="direccion" class="form-label">Direccion</label>
                            <input type="text" class="form-control <?php echo $direccionError ? 'is-invalid' : ''; ?>" id="direccion" name="direccion" value="<?php echo htmlspecialchars($direccion); ?>">
                            <div class="invalid-feedback"><?php echo $direccionError; ?></div>
                        </div>
                        <div class="d-flex flex-column flex-sm-row justify-content-between gap-2">
                            <button type="submit" class="btn btn-success px-4">Guardar</button>
                            <a href="../../vista/propietarios.php" class="btn btn-secondary px-4">Volver</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>