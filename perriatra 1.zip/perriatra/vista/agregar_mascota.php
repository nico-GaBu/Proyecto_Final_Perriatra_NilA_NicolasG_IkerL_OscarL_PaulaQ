<?php
session_start();
if (!isset($_SESSION['nombre'])) {
    header('Location: ./login.php');
    exit();
}
include '../procesos/connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Mascota</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <script src="../js/validacion.js"></script>
    <style>
        .error-text { color: red; font-size: 0.9em; }
    </style>
</head>
<body class="index-bg">
    <?php
    require_once '../procesos/connect.php';
    ?>
    <div class="container min-vh-100 d-flex align-items-center justify-content-center">
        <div class="card shadow p-4" style="max-width: 600px; width: 100%;">
            <div class="card-body">
                <h1 class="mb-4 text-green text-center">Añadir Nueva Mascota</h1>
                <form action="../procesos/insertar/insert_mascota.php" method="POST" enctype="multipart/form-data" onsubmit="return validarFormularioMascota();">
                    <div class="form-group mb-3">
                        <label for="nombre" class="form-label">Nombre:</label>
                        <input type="text" id="nombre" name="nombre" maxlength="25" class="form-control" required>
                        <div id="error-nombre" class="error-text"></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="especie" class="form-label">Especie:</label>
                        <input type="text" id="especie" name="especie" maxlength="3" class="form-control" required>
                        <div id="error-especie" class="error-text"></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="raza" class="form-label">Raza:</label>
                        <select id="raza" name="raza" class="form-control" required>
                            <option value="">Seleccione una raza</option>
                            <?php
                            $sql = "SELECT * FROM raza";
                            $result = mysqli_query($conn, $sql);
                            if ($result) {
                                $razas = mysqli_fetch_all($result, MYSQLI_ASSOC);
                                foreach ($razas as $row) {
                                    $selected = ($row['Id'] == ($mascota['Raza'] ?? '')) ? "selected" : "";
                                    echo "<option value='" . htmlspecialchars($row['Id']) . "' $selected>" . htmlspecialchars($row['Nombre']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                        <div id="error-raza" class="error-text"></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="genere" class="form-label">Género:</label>
                        <input type="text" id="genere" name="genere" maxlength="1" class="form-control" required oninput="this.value = this.value.toUpperCase()">
                        <div id="error-genero" class="error-text"></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="fecha_nacimiento" class="form-label">Fecha de Nacimiento:</label>
                        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" class="form-control" required>
                        <div id="error-fecha" class="error-text"></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="propietario" class="form-label">Propietario:</label>
                        <select id="propietario" name="propietario" class="form-control" required>
                            <option value="">Seleccione un propietario</option>
                            <?php
                            $sql = "SELECT * FROM propietario";
                            $result = mysqli_query($conn, $sql);
                            if ($result) {
                                $propietarios = mysqli_fetch_all($result, MYSQLI_ASSOC);
                                foreach ($propietarios as $row) {
                                    $selected = ($row['DNI'] == ($mascota['Propietario'] ?? '')) ? "selected" : "";
                                    echo "<option value='" . htmlspecialchars($row['DNI']) . "' $selected>" . htmlspecialchars($row['Nombre']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label for="vet" class="form-label">Veterinario:</label>
                        <select id="vet" name="vet" class="form-control" required>
                            <option value="">Seleccione un veterinario</option>
                            <?php
                            $sql = "SELECT * FROM veterinario";
                            $result = mysqli_query($conn, $sql);
                            if ($result) {
                                $veterinarios = mysqli_fetch_all($result, MYSQLI_ASSOC);
                                foreach ($veterinarios as $row) {
                                    $selected = ($row['Id'] == ($mascota['Vet'] ?? '')) ? "selected" : "";
                                    echo "<option value='" . htmlspecialchars($row['Id']) . "' $selected>" . htmlspecialchars($row['Nombre']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-green">Guardar Mascota</button>
                        <a href="../index.php" class="btn btn-secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        // Limpia los mensajes de error
        function limpiarErroresMascota() {
            document.getElementById("error-nombre").textContent = "";
            document.getElementById("error-especie").textContent = "";
            document.getElementById("error-raza").textContent = "";
            document.getElementById("error-genero").textContent = "";
            document.getElementById("error-fecha").textContent = "";
        }

        // Sobrescribe la función para mostrar errores en rojo
        function validarFormularioMascota() {
            limpiarErroresMascota();
            let valido = true;

            if (document.getElementById("nombre").value.trim() === "") {
                document.getElementById("error-nombre").textContent = "El nombre no puede estar vacío.";
                valido = false;
            }
            if (document.getElementById("especie").value.trim() === "") {
                document.getElementById("error-especie").textContent = "La especie no puede estar vacía.";
                valido = false;
            }
            if (document.getElementById("raza").value.trim() === "") {
                document.getElementById("error-raza").textContent = "La raza no puede estar vacía.";
                valido = false;
            }
            if (document.getElementById("genere").value.trim() === "") {
                document.getElementById("error-genero").textContent = "El género no puede estar vacío.";
                valido = false;
            }
            if (document.getElementById("fecha").value.trim() === "") {
                document.getElementById("error-fecha").textContent = "La fecha no puede estar vacía.";
                valido = false;
            }
            return valido;
        }
    </script>
</body>
</html>