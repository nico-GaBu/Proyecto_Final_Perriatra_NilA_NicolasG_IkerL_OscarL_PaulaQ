<?php
session_start();
if (!isset($_SESSION['nombre'])) {
    header('Location: ./login.php');
    exit();
}   
include '../procesos/connect.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Propietarios</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body class="bg-green">
    <div class="container py-4 py-md-5">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 gap-3">
            <h1 class="mb-0 text-white">Lista de Propietarios</h1>
            <a href="../procesos/insertar/insert_propietarios.php" class="btn btn-success">Añadir Propietario</a>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>DNI</th>
                        <th>Nombre</th>
                        <th>Teléfono</th>
                        <th>Mail</th>
                        <th>Direccion</th>
                        <th>ID Mascota(s)</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $sql = "SELECT * FROM propietario";
                $result = mysqli_query($conn, $sql);

                if ($result && mysqli_num_rows($result) > 0) {
                    $propietarios = mysqli_fetch_all($result, MYSQLI_ASSOC);

                    foreach ($propietarios as $row) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['DNI']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['Nombre']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['Telf']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['Mail']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['Direccion']) . "</td>";

                        // Obtener los IDs de mascotas asociadas a este propietario
                        $id_propietario = $row['DNI'];
                        $sql_mascotas = "SELECT Chip FROM mascota WHERE Propietario = '$id_propietario'";
                        $result_mascotas = mysqli_query($conn, $sql_mascotas);
                        $ids_mascotas = [];

                        if ($result_mascotas && mysqli_num_rows($result_mascotas) > 0) {
                            $mascotas = mysqli_fetch_all($result_mascotas, MYSQLI_ASSOC);
                            foreach ($mascotas as $mascota) {
                                $ids_mascotas[] = htmlspecialchars($mascota['Chip']);
                            }
                        }

                        echo "<td>" . (count($ids_mascotas) ? implode(', ', $ids_mascotas) : 'Sin mascotas') . "</td>";

                        echo "<td>";
                        echo "<a href='../procesos/modificar/modificar_propietario.php?DNI=" . urlencode($row['DNI']) . "' class='btn btn-warning btn-sm me-2'>Editar</a>";
                        echo "<a href='../procesos/eliminar/eliminar_propietario.php?DNI=" . urlencode($row['DNI']) . "' class='btn btn-danger btn-sm'>Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                }
                ?>
                </tbody>
            </table>
        </div>
        <a href="../index.php" class="btn btn-secondary mt-3">Volver</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>
</html>