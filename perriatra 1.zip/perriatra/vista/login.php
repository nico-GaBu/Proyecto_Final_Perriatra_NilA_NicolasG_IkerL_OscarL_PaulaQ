<?php
session_start();
if (isset($_SESSION['nombre'])) {
    header('Location: ../index.php'); // ya ha iniciado sesión
    exit();
}
?>
<?php

$usernameError = $passwordError = "";
$username = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["nombre"])) {
        $usernameError = "El nombre de usuario es obligatorio.";
    } else {
        $username = htmlspecialchars($_POST["nombre"]);
    }

    if (empty($_POST["pass"])) {
        $passwordError = "La contraseña es obligatoria.";
    } else {
        $password = htmlspecialchars($_POST["pass"]);
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Perriatra</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .error-text { color: red; font-size: 0.9em; }
    </style>
</head>

<body class="login-bg">
    <div class="container min-vh-100 d-flex align-items-center justify-content-center">
        <div class="card shadow p-4" style="max-width: 400px; width: 100%;">
            <div class="card-body">
                <h2 class="card-title text-center mb-4 login-title-green">Iniciar Sesión</h2>
                <form action="../procesos/login_veterinario.php" method="POST" novalidate onsubmit="return validarFormularioLogin();">
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Usuario</label>
                        <input type="text" class="form-control <?php echo $usernameError ? 'is-invalid' : ''; ?>" name="nombre" id="nombre" placeholder="Introducir usuario" value="<?php echo htmlspecialchars($username); ?>" onblur="validarNombreLogin()">
                        <div id="nombre-error" class="error-text"><?php echo $usernameError; ?></div>
                    </div>
                    <div class="mb-3">
                        <label for="pass" class="form-label">Contraseña</label>
                        <input type="password" class="form-control <?php echo $passwordError ? 'is-invalid' : ''; ?>" name="pass" id="pass" placeholder="Introducir contraseña" onblur="validarContrasenaLogin()">
                        <div id="pass-error" class="error-text"><?php echo $passwordError; ?></div>
                    </div>
                    <div class="d-grid mb-2">
                        <button type="submit" name="login" class="btn btn-primary">Login</button>
                    </div>
                </form>
                <div class="text-center mt-3">
                    <span>¿No tienes cuenta? <a href="registro.php">¡Regístrate!</a></span>
                </div>
            </div>
        </div>
    </div>
    <script src="../js/validacion.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>