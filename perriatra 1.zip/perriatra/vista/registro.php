<?php
session_start();

$email = $username = $pass = $passConf = $especialidad = $telefono = $salario = $fecha = "";
$emailError = $usernameError = $passError = $passConfError = $especialidadError = $telefonoError = $salarioError = $fechaError = "";
$validForm = true;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar Email
    if (empty($_POST["email"])) {
        $emailError = "El email es obligatorio.";
        $validForm = false;
    } else {
        $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailError = "El email no es válido.";
            $validForm = false;
        }
    }

    // Validar nombre de usuario
    if (empty($_POST["username"])) {
        $usernameError = "El nombre de usuario es obligatorio.";
        $validForm = false;
    } else {
        $username = trim($_POST["username"]);
        if (strlen($username) < 3) {
            $usernameError = "El nombre de usuario debe tener al menos 3 caracteres.";
            $validForm = false;
        }
    }

    // Validar contraseña (mínimo 6 caracteres)
    if (empty($_POST["pass"])) {
        $passError = "La contraseña es obligatoria.";
        $validForm = false;
    } else {
        $pass = $_POST["pass"];
        if (strlen($pass) < 6) {
            $passError = "La contraseña debe tener al menos 6 caracteres.";
            $validForm = false;
        }
    }

    // Confirmar contraseña
    if (empty($_POST["passConf"])) {
        $passConfError = "La confirmación de la contraseña es obligatoria.";
        $validForm = false;
    } else {
        $passConf = $_POST["passConf"];
        if ($pass !== $passConf) {
            $passConfError = "Las contraseñas no coinciden.";
            $validForm = false;
        }
    }

    // Validar especialidad
    if (empty($_POST['especialidad'])) {
        $especialidadError = "La especialidad es obligatoria.";
        $validForm = false;
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $_POST['especialidad'])) {
        $especialidadError = "La especialidad solo debe contener letras y espacios.";
        $validForm = false;
    } else {
        $especialidad = $_POST['especialidad'];
    }

    // Validar telefono
    if (empty($_POST['telefono'])) {
        $telefonoError = "El teléfono es obligatorio.";
        $validForm = false;
    } elseif (!preg_match("/^[0-9]{9,15}$/", $_POST['telefono'])) {
        $telefonoError = "El teléfono debe contener entre 9 y 15 dígitos.";
        $validForm = false;
    } else {
        $telefono = $_POST['telefono'];
    }

    // Validar salario
    if (empty($_POST['salario'])) {
        $salarioError = "El salario es obligatorio.";
        $validForm = false;
    } elseif (!is_numeric($_POST['salario']) || $_POST['salario'] < 0) {
        $salarioError = "El salario debe ser un número positivo.";
        $validForm = false;
    } else {
        $salario = $_POST['salario'];
    }

    // Validar fecha
    if (empty($_POST['fecha'])) {
        $fechaError = "La fecha de contratación es obligatoria.";
        $validForm = false;
    } elseif (!DateTime::createFromFormat('Y-m-d', $_POST['fecha'])) {
        $fechaError = "Formato de fecha no válido.";
        $validForm = false;
    } else {
        $fecha = $_POST['fecha'];
    }

    // Si el formulario es válido, redirigir o procesar
    if ($validForm) {
        // ...procesar datos o redirigir...
         header("Location: ../index.php");
         exit();
        echo "<div class='alert alert-success'>Formulario válido y procesado correctamente.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Veterinario</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .error-text { color: red; font-size: 0.9em; }
    </style>
</head>
<body class="bg-green d-flex align-items-center min-vh-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-7 col-lg-5 px-1 px-sm-2">
                <div class="card shadow-lg p-2 p-sm-3">
                    <div class="card-header bg-green text-white text-center rounded mb-4">
                        <h2 class="mb-0 text-white">Registro de Veterinario</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="../procesos/register_veterinario.php" onsubmit="return validarFormularioRegistroVeterinario();">
                            <div class="mb-3">
                                <label for="email" class="form-label">Correo electrónico</label>
                                <input type="email" class="form-control <?php echo $emailError ? 'is-invalid' : ''; ?>" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" placeholder="Introduce email" onblur="validarEmailRegistro()">
                                <div id="email-error" class="error-text"><?php echo $emailError; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Usuario</label>
                                <input type="text" class="form-control <?php echo $usernameError ? 'is-invalid' : ''; ?>" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" placeholder="Introduce usuario" onblur="validarNombreLogin()">
                                <div id="nombre-error" class="error-text"><?php echo $usernameError; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="pass" class="form-label">Contraseña</label>
                                <input type="password" class="form-control <?php echo $passError ? 'is-invalid' : ''; ?>" id="pass" name="pass" placeholder="Introduce contraseña" onblur="validarContrasenaLogin()">
                                <div id="pass-error" class="error-text"><?php echo $passError; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="passConf" class="form-label">Confirmar contraseña</label>
                                <input type="password" class="form-control <?php echo $passConfError ? 'is-invalid' : ''; ?>" id="passConf" name="passConf" placeholder="Confirma contraseña" onblur="validarConfirmarContrasenaRegistro()">
                                <div id="confirmarPass-error" class="error-text"><?php echo $passConfError; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="especialidad" class="form-label">Especialidad</label>
                                <input type="text" class="form-control <?php echo $especialidadError ? 'is-invalid' : ''; ?>" id="especialidad" name="especialidad" value="<?php echo htmlspecialchars($especialidad); ?>" placeholder="Introduce especialidad" onblur="validarEspecialidad()">
                                <div id="especialidad-error" class="error-text"><?php echo $especialidadError; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="telefono" class="form-label">Teléfono</label>
                                <input type="number" class="form-control <?php echo $telefonoError ? 'is-invalid' : ''; ?>" id="telefono" name="telefono" value="<?php echo htmlspecialchars($telefono); ?>" placeholder="Introduce teléfono" onblur="validarTelefono()">
                                <div id="telefono-error" class="error-text"><?php echo $telefonoError; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="salario" class="form-label">Salario</label>
                                <input type="text" class="form-control <?php echo $salarioError ? 'is-invalid' : ''; ?>" id="salario" name="salario" value="<?php echo htmlspecialchars($salario); ?>" placeholder="Introduce salario" onblur="validarSalario()">
                                <div id="salario-error" class="error-text"><?php echo $salarioError; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="fecha" class="form-label">Fecha de contratación</label>
                                <input type="date" class="form-control <?php echo $fechaError ? 'is-invalid' : ''; ?>" id="fecha" name="fecha" value="<?php echo htmlspecialchars($fecha); ?>" onblur="validarFechaRegistro()">
                                <div id="fecha-error" class="error-text"><?php echo $fechaError; ?></div>
                            </div>
                            <div class="d-grid">
                                <button type="submit" name="registro" class="btn btn-success">Registrarse</button>
                            </div>
                        </form>
                        <div class="mt-3 text-center">
                            <span>¿Ya tienes cuenta? <a href="../index.php">Inicia sesión</a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../js/validacion.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>