-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_perriatra
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mascota`
--

DROP TABLE IF EXISTS `mascota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mascota` (
  `Chip` int NOT NULL,
  `Nombre` varchar(25) NOT NULL,
  `Genere` varchar(1) NOT NULL,
  `Especie` varchar(3) NOT NULL,
  `Raza` int DEFAULT NULL,
  `Fecha_Nacimiento` date DEFAULT NULL,
  `Propietario` int DEFAULT NULL,
  `Vet` int DEFAULT NULL,
  `Historial` int DEFAULT NULL,
  PRIMARY KEY (`Chip`),
  KEY `mascota_raza_fk` (`Raza`),
  KEY `mascota_propietario_fk` (`Propietario`),
  KEY `mascota_vet_fk` (`Vet`),
  KEY `mascota_historial_fk` (`Historial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mascota`
--

LOCK TABLES `mascota` WRITE;
/*!40000 ALTER TABLE `mascota` DISABLE KEYS */;
INSERT INTO `mascota` VALUES (3301,'DUC','M','gat',110,'2011-10-02',44999222,21,11),(3302,'IBIS','H','gat',108,'2011-07-30',44999222,21,1),(3304,'BRU','M','gat',112,'2011-12-09',44666222,27,3),(3305,'GINKGO','M','per',104,'2010-10-10',44666222,23,4),(3306,'IBIS','F','per',109,'2011-11-11',44888999,22,5),(3307,'GARFIEL','M','gat',107,'2012-02-22',44888999,24,6),(3308,'KENZO','M','per',101,'2010-04-27',44222111,24,7),(3309,'LEO','M','per',109,'2011-03-18',44999333,25,8),(3310,'MANCHA','F','gat',102,'2012-02-02',44999333,27,9),(3311,'ANOUK','M','gat',103,'2010-07-07',44666888,26,10),(3312,'NUKA','F','gos',104,'2011-01-07',44666222,23,12);
/*!40000 ALTER TABLE `mascota` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-05 19:22:17
